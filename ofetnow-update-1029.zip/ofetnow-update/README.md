# OFETNow: preprocessing and duplicate-input control

## Processing

`features_unscaled.csv` contains 512 records and 2213 numerical input features before normalization; `labels.csv` contains the corresponding mobility (`labels1`) and carrier-type (`labels2`) labels in the same row order. 

Five conflicting record pairs were addressed: mobility labels were standardized to the high-mobility class in four pairs, and the environment encoding was corrected in the fifth.

Records with identical **complete input-feature vectors** stay together in every outer training/test split and inner training/validation split. The procedure uses 10 outer folds and 9 inner folds. Splitting precedes normalization: all features are standardized using StandardScaler, with scaling parameters and ExtraTrees feature selection fitted only on each training fold. The number of selected features remains the same as in the original analysis. Hyperparameters are selected using inner CV; outer test folds are used for evaluation only. The code checks that identical inputs never cross a split.

## Scientific conclusion

The completed eight-seed validation remains consistent with the main qualitative conclusion that molecular and device features provide predictive information for OFET mobility class and carrier type. 

## Run

Completed eight-seed results are included in `results/`: summary statistics, per-seed and per-fold metrics, test predictions, tuning trials, and the split-overlap audit.

Python 3.12.

```sh
python -m pip install -r requirements.txt
python evaluate.py --output rerun_results
```

New results are saved in `rerun_results/`.

