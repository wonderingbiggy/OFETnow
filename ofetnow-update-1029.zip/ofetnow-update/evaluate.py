"""Nested CV with training-fold preprocessing and identical-input isolation.

MIT License
Copyright (c) 2026 Yuan-Kai Li

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import optuna
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

ROOT = Path(__file__).resolve().parent
SEEDS = [63098494, 134095158, 139129803, 275887943,
         832156935, 847570839, 1556675597, 1582600549]
OBJECTIVES = {"labels1": ["high_f1", "macro_f1"],
              "labels2": ["accuracy", "macro_f1"]}
FEATURE_COUNTS = {"labels1": 244, "labels2": 334}


def load_data(features, labels):
    x, y = pd.read_csv(features), pd.read_csv(labels)
    if x.shape != (512, 2213) or y.shape != (512, 2):
        raise ValueError("Expected the supplied 512-row feature and label files.")
    if y.columns.tolist() != ["labels1", "labels2"] or not x.columns.is_unique:
        raise ValueError("Unexpected column names.")
    if not np.isfinite(x.to_numpy()).all() or not np.isfinite(y.to_numpy()).all():
        raise ValueError("Inputs must contain finite numerical values.")
    if set(y.labels1) != {0, 1} or set(y.labels2) != {0, 1, 2}:
        raise ValueError("Unexpected labels.")
    # All input columns define identity; target labels are not part of grouping.
    _, groups = np.unique(x.to_numpy(), axis=0, return_inverse=True)
    return x, y, groups


def split(x, y, groups, folds, seed):
    cv = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
    for train, held_out in cv.split(x, y, groups):
        if not set(groups[train]).isdisjoint(groups[held_out]):
            raise RuntimeError("Identical inputs cross a split.")
        if set(y[train]) != set(y) or set(y[held_out]) != set(y):
            raise RuntimeError("A split is missing a target class.")
        yield train, held_out


def preprocess(x_train, y_train, x_held_out, k, seed):
    scaler = StandardScaler().fit(x_train)
    train = scaler.transform(x_train).astype(np.float32)
    held_out = scaler.transform(x_held_out).astype(np.float32)
    selector = ExtraTreesClassifier(n_estimators=128, min_samples_leaf=2,
                                   max_features="sqrt", random_state=seed, n_jobs=1)
    selector.fit(train, y_train)
    chosen = np.sort(np.argsort(-selector.feature_importances_, kind="stable")[:k])
    return train[:, chosen], held_out[:, chosen], chosen


def model(params, seed):
    return XGBClassifier(**params, random_state=seed, n_jobs=1,
                         verbosity=0, tree_method="hist")


def parameters(trial):
    return {
        "n_estimators": trial.suggest_int("n_estimators", 100, 600),
        "max_depth": trial.suggest_int("max_depth", 3, 10),
        "learning_rate": trial.suggest_float("learning_rate", 0.02, 0.2),
        "subsample": trial.suggest_float("subsample", 0.5, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 0.9),
    }


def metrics(truth, prediction, task):
    values = {"accuracy": float(accuracy_score(truth, prediction)),
              "balanced_accuracy": float(balanced_accuracy_score(truth, prediction)),
              "macro_f1": float(f1_score(truth, prediction, average="macro", zero_division=0))}
    if task == "labels1":
        values["high_f1"] = float(f1_score(truth, prediction, zero_division=0))
    return values


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--features", type=Path, default=ROOT / "features_unscaled.csv")
    parser.add_argument("--labels", type=Path, default=ROOT / "labels.csv")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--smoke-test", action="store_true")
    args = parser.parse_args()
    x, targets, groups = load_data(args.features, args.labels)
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("Use a new or empty output directory; existing results are not overwritten.")
    args.output.mkdir(parents=True, exist_ok=True)
    seeds, trials = (SEEDS[:1], 1) if args.smoke_test else (SEEDS, 12)
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    config = {"seeds": seeds, "outer_folds": 10, "inner_folds": 9,
              "outer_folds_to_run": 1 if args.smoke_test else 10,
              "trials_per_outer_fold": trials, "objectives": OBJECTIVES,
              "feature_counts": FEATURE_COUNTS, "exact_input_groups": int(len(np.unique(groups))),
              "smoke_test": args.smoke_test,
              "features_sha256": hashlib.sha256(args.features.read_bytes()).hexdigest(),
              "labels_sha256": hashlib.sha256(args.labels.read_bytes()).hexdigest()}
    (args.output / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    predictions, trial_rows, split_rows = [], [], []

    for seed in seeds:
        for task, objectives in OBJECTIVES.items():
            y = targets[task].to_numpy(dtype=np.int32)
            offset = 0 if task == "labels1" else 1000
            for fold, (train, test) in enumerate(split(x, y, groups, 10, seed + offset), 1):
                if args.smoke_test and fold > 1:
                    break
                fit_seed = seed + offset + fold
                x_outer, y_outer = x.iloc[train], y[train]
                prepared = []
                for inner, (it, iv) in enumerate(split(x_outer, y_outer, groups[train], 9, fit_seed), 1):
                    xt, xv, _ = preprocess(x_outer.iloc[it], y_outer[it], x_outer.iloc[iv],
                                          FEATURE_COUNTS[task], fit_seed + inner)
                    prepared.append((xt, y_outer[it], xv, y_outer[iv]))
                    split_rows.append({"seed": seed, "task": task, "outer_fold": fold,
                                       "inner_fold": inner, "train_rows": train[it].tolist(),
                                       "validation_rows": train[iv].tolist(), "test_rows": test.tolist()})
                xt, xe, selected = preprocess(x_outer, y_outer, x.iloc[test],
                                              FEATURE_COUNTS[task], fit_seed + 100)
                for objective in objectives:
                    study = optuna.create_study(direction="maximize",
                        sampler=optuna.samplers.TPESampler(seed=fit_seed, n_startup_trials=4))

                    def score_trial(trial):
                        params = parameters(trial)
                        scores = []
                        for a, b, c, d in prepared:
                            fitted = model(params, fit_seed).fit(a, b)
                            scores.append(metrics(d, fitted.predict(c), task)[objective])
                        return float(np.mean(scores))

                    study.optimize(score_trial, n_trials=trials)
                    fitted = model(study.best_params, fit_seed).fit(xt, y_outer)
                    pred = fitted.predict(xe).astype(int)
                    record = {"seed": seed, "task": task, "objective": objective, "fold": fold,
                              "train_rows": train.tolist(), "test_rows": test.tolist(),
                              "selected_features": x.columns[selected].tolist(),
                              "best_params": study.best_params, "best_inner_score": study.best_value,
                              "true": y[test].tolist(), "pred": pred.tolist(),
                              **metrics(y[test], pred, task)}
                    with (args.output / "folds.jsonl").open("a", encoding="utf-8") as handle:
                        handle.write(json.dumps(record) + "\n")
                    predictions.extend({"seed": seed, "task": task, "objective": objective,
                                        "fold": fold, "row": int(row), "true": int(truth), "pred": int(value)}
                                       for row, truth, value in zip(test, y[test], pred))
                    trial_rows.extend({"seed": seed, "task": task, "objective": objective,
                                       "fold": fold, "trial": t.number, "inner_score": t.value, **t.params}
                                      for t in study.trials)
                    print(f"seed={seed} {task}/{objective} fold={fold}: {record[objective]:.4f}", flush=True)

    frame = pd.DataFrame(predictions)
    frame.to_csv(args.output / "predictions.csv", index=False)
    pd.DataFrame(trial_rows).to_csv(args.output / "trials.csv", index=False)
    (args.output / "splits.jsonl").write_text(
        "".join(json.dumps(row) + "\n" for row in split_rows), encoding="utf-8")
    if not args.smoke_test:
        rows = []
        for (seed, task, objective), block in frame.groupby(["seed", "task", "objective"]):
            if sorted(block.row) != list(range(len(x))):
                raise RuntimeError("Each record must appear in the outer test set exactly once.")
            rows.append({"seed": seed, "task": task, "objective": objective,
                         **metrics(block.true, block.pred, task)})
        complete = pd.DataFrame(rows)
        complete.to_csv(args.output / "seed_results.csv", index=False)
        summary = []
        for (task, objective), block in complete.groupby(["task", "objective"]):
            for metric in metrics([0, 1], [0, 1], task):
                values = block[metric]
                summary.append({"task": task, "objective": objective, "metric": metric,
                                "mean": values.mean(), "sample_sd": values.std(ddof=1)})
        pd.DataFrame(summary).to_csv(args.output / "summary.csv", index=False)
    print("Smoke test complete." if args.smoke_test else "Nested CV complete.")


if __name__ == "__main__":
    main()
